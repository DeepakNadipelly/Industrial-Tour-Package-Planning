/* SystemJS module definition */
declare var module: NodeModule;
declare var xepOnline: any;
interface NodeModule {
  id: string;
}
